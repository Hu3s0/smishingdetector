# api/main.py

import joblib
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
import sys

# Añadir el directorio raíz al path para poder importar los módulos locales
# Esto es crucial para que la API pueda encontrar 'utils' y 'rules'
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from utils.preprocessing import preprocess_text
from rules.rules import check_heuristic_rules

# --- Creación de la App FastAPI ---
app = FastAPI(
    title="Smishing Detector API",
    description="Una API para detectar mensajes de smishing usando un modelo de ML y reglas heurísticas.",
    version="1.0.0"
)

# --- Carga de Modelos ---
# Escalabilidad:
# - En un entorno de producción, los modelos no deberían cargarse desde archivos locales
#   directamente en el código de la API. Sería mejor usar un registro de modelos
#   (como MLflow, S3, etc.) para versionar y servir los modelos.
# - La carga podría gestionarse en un evento 'startup' de FastAPI para asegurar que los
#   modelos estén listos antes de que la app empiece a aceptar peticiones.

MODELS_DIR = 'models/'
VECTORIZER_PATH = os.path.join(MODELS_DIR, 'vectorizer.pkl')
CLASSIFIER_PATH = os.path.join(MODELS_DIR, 'classifier.pkl')

try:
    vectorizer = joblib.load(VECTORIZER_PATH)
    classifier = joblib.load(CLASSIFIER_PATH)
    print("Modelos cargados correctamente.")
except FileNotFoundError:
    print("Error: No se encontraron los archivos del modelo. Asegúrate de ejecutar 'train/train.py' primero.")
    # En un caso real, podrías querer que la app no se inicie si los modelos no están.
    # Aquí, por simplicidad, solo imprimimos un error. La app fallará en /predict.
    vectorizer = None
    classifier = None

# --- Modelos de Datos (Pydantic) ---
class PredictionRequest(BaseModel):
    message: str

class PredictionResponse(BaseModel):
    prediction: str
    score: float
    triggered_rules: list[str]

# --- Endpoints de la API ---

from fastapi.responses import FileResponse

@app.get("/", response_class=FileResponse, tags=["General"])
def read_root():
    """
    Endpoint raíz que sirve la página de análisis de mensajes.
    """
    return os.path.join(os.path.dirname(__file__), "index.html")

@app.post("/predict", response_model=PredictionResponse, tags=["Prediction"])
def predict_smishing(request: PredictionRequest):
    """
    Analiza un mensaje SMS para detectar si es smishing.

    Recibe un mensaje de texto y devuelve:
    - **prediction**: "smishing" o "legítimo".
    - **score**: La probabilidad de que el mensaje sea smishing (de 0.0 a 1.0).
    - **triggered_rules**: Una lista de las reglas heurísticas que se activaron.
    """
    if not vectorizer or not classifier:
        raise HTTPException(
            status_code=500,
            detail="Modelos no cargados. Por favor, entrene el modelo antes de usar la API."
        )

    sms_text = request.message

    # 1. Aplicar reglas heurísticas sobre el texto original
    triggered_rules = check_heuristic_rules(sms_text)

    # 2. Preprocesar el texto para el modelo de ML
    processed_text = preprocess_text(sms_text)

    # 3. Vectorizar el texto preprocesado
    text_tfidf = vectorizer.transform([processed_text])

    # 4. Realizar la predicción y obtener probabilidades
    prediction_proba = classifier.predict_proba(text_tfidf)
    smishing_score = prediction_proba[0][1] # Probabilidad de la clase '1' (smishing)
    
    # 5. Determinar la etiqueta final
    # Se puede definir un umbral. Aquí usamos 0.5 como umbral por defecto.
    prediction_label = "smishing" if smishing_score > 0.5 else "legítimo"

    # Escalabilidad:
    # - Logging: Aquí se debería registrar la petición, el texto y la respuesta.
    #   (ej. usando el módulo `logging` de Python).
    # - Base de Datos: La predicción y sus detalles podrían guardarse en una base de datos
    #   (SQLite, PostgreSQL) para análisis futuros o para un panel de control avanzado.
    # - Autenticación: Se podría proteger este endpoint para que solo usuarios
    #   autenticados puedan usarlo (ej. con FastAPI's `Depends` y OAuth2).

    return {
        "prediction": prediction_label,
        "score": smishing_score,
        "triggered_rules": triggered_rules
    }

# Para ejecutar la API, usa el comando:
# uvicorn api.main:app --reload
#
# El flag --reload es útil para desarrollo, ya que reinicia el servidor
# automáticamente cuando detecta cambios en el código.
