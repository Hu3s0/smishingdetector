# rules/rules.py

import re

# --- Definición de Reglas Heurísticas ---
# Cada regla es un diccionario con un nombre, una descripción y un patrón regex.
# Escalabilidad:
# - Las reglas se pueden mover a un archivo de configuración (YAML, JSON) para
#   que puedan ser modificadas sin cambiar el código.
# - Se podrían añadir reglas más complejas que no solo usen regex, sino también
#   funciones personalizadas (ej. verificar si una URL está en una lista negra de dominios).
# - Se puede implementar un sistema de ponderación, donde cada regla tiene un peso
#   diferente para calcular un "score de riesgo" más granular.

HEURISTIC_RULES = [
    {
        "name": "shortened_url",
        "description": "Contiene una URL acortada (potencialmente para ofuscar el destino).",
        "pattern": re.compile(r'bit\.ly|t\.co|goo\.gl|ow\.ly|tinyurl\.com', re.IGNORECASE)
    },
    {
        "name": "urgent_language",
        "description": "Usa lenguaje que denota urgencia para presionar al usuario.",
        "pattern": re.compile(r'urgente|inmediato|ahora|actúa|expira|vence pronto', re.IGNORECASE)
    },
    {
        "name": "financial_terms",
        "description": "Menciona términos financieros o de cuentas sensibles.",
        "pattern": re.compile(r'banco|cuenta|tarjeta|crédito|contraseña|password|factura|pago|deuda', re.IGNORECASE)
    },
    {
        "name": "suspicious_sender",
        "description": "El texto sugiere un remitente genérico o una autoridad no verificable.",
        "pattern": re.compile(r'servicio|proveedor|notificación|entrega|autoridad', re.IGNORECASE)
    },
    {
        "name": "prize_or_lottery",
        "description": "Menciona premios, loterías o regalos inesperados.",
        "pattern": re.compile(r'felicidades|ganado|premio|lotería|sorteo|gratis', re.IGNORECASE)
    }
]

def check_heuristic_rules(text: str) -> list:
    """
    Aplica un conjunto de reglas heurísticas a un mensaje de texto.

    Args:
        text (str): El mensaje SMS a analizar.

    Returns:
        list: Una lista de las descripciones de las reglas que se activaron.
              Devuelve una lista vacía si no se activa ninguna regla.
    """
    triggered_rules = []
    for rule in HEURISTIC_RULES:
        if rule["pattern"].search(text):
            triggered_rules.append(rule["description"])
    return triggered_rules

if __name__ == '__main__':
    # Ejemplos de uso
    smishing_sms = "URGENTE: Tu cuenta bancaria ha sido comprometida. Reclama tu acceso ahora en http://bit.ly/fakebank"
    legit_sms = "Hola, te recuerdo la cita de mañana a las 10am. Saludos."

    print(f"Analizando mensaje 1: '{smishing_sms}'")
    triggered = check_heuristic_rules(smishing_sms)
    if triggered:
        print("Reglas disparadas:")
        for desc in triggered:
            print(f"- {desc}")
    else:
        print("No se disparó ninguna regla.")

    print("\n" + "="*30 + "\n")

    print(f"Analizando mensaje 2: '{legit_sms}'")
    triggered_2 = check_heuristic_rules(legit_sms)
    if triggered_2:
        print("Reglas disparadas:")
        for desc in triggered_2:
            print(f"- {desc}")
    else:
        print("No se disparó ninguna regla.")
